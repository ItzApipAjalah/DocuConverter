const fs = require('fs');
const ipynb2html = require('ipynb2html');

console.log(ipynb2html);
