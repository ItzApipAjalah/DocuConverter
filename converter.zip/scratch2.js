const fs = require('fs');
const ipynb2html = require('ipynb2html');
const { JSDOM } = require('jsdom');

const render = ipynb2html.createRenderer(new JSDOM().window.document);
const notebookObj = JSON.parse(fs.readFileSync('1_Tekrek_M8_Notebook_Image (1).ipynb', 'utf8'));
const element = render(notebookObj);
console.log(element.outerHTML.substring(0, 500));
